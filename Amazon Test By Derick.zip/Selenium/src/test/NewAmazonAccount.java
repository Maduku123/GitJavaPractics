package test;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewAmazonAccount {
	WebDriver driver;
	@BeforeMethod
	public void webPageInitialization() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\cashp\\OneDrive\\Desktop\\ChromeDriver\\chromedriver.exe");
		 driver = new ChromeDriver();
			driver.get("https://www.amazon.com/");
			System.out.println(driver.getTitle());
			driver.manage().window().maximize();
			//implicit wait once defind apply to all element.
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	}
	@AfterMethod
	public void closedBrowser() {
		driver.close();
		
	}
	@Test
	public void nagetiveSignInTest() {
		WebElement accountAndList= driver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
		Actions action = new Actions(driver);
		action.moveToElement(accountAndList).click().build().perform();
		String expectedResult="Sign-In";
		String actualResult=driver.findElement(By.xpath("//h1[contains(text(),'Sign-In')]")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectedResult);
		
	}
	@Test
	public void provideValidEmailOrPhoneNumber() throws IOException {
		WebElement accountAndList= driver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
		Actions action = new Actions(driver);
		action.moveToElement(accountAndList).click().build().perform();
		action.moveToElement(driver.findElement(By.xpath("//input[@id='ap_email']"))).sendKeys("pekiakaderick@gmail.com").build().perform();
		action.moveToElement(driver.findElement(By.id("continue"))).click().build().perform();
		action.moveToElement(driver.findElement(By.xpath("//input[@id='ap_password']"))).sendKeys("Patderick123").build().perform();
		action.moveToElement(driver.findElement(By.xpath("//input[@id='signInSubmit']"))).click().build().perform();
		String expectResult="There was a problem";
		String actualResult=driver.findElement(By.xpath("//h4[contains(text(),'There was a problem')]")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectResult);
		
	}
	@Test
	public void itemInCartTest() {
		driver.findElement(By.xpath("//div[@id='nav-cart-count-container']")).click();
		String epectedMsge="Your Amazon Cart is empty";
		String actualMge=driver.findElement(By.xpath("//h2[contains(text(),'Your Amazon Cart is empty')]")).getText();
		System.out.println(actualMge);
		Assert.assertEquals(actualMge, epectedMsge);
	}
	@Test
	public void orderMedicationTest() {
		driver.findElement(By.xpath("//a[contains(text(),'Pharmacy')]")).click();
		WebElement chooseState=driver.findElement(By.xpath("//select[@id='usState-availability-check']"));
		//chooseState.click();
		Select state = new Select(chooseState);
		state.selectByIndex(8);
		String ExpectedResult="We are available in your area";
		String ActualResult=driver.findElement(By.xpath("//div[@id='lookup-eligibility-text']")).getText();
		System.out.println(ActualResult);
		Assert.assertEquals(ActualResult, ExpectedResult);
		
	}
	@Test
	public void positiveSignInTest() {
		WebElement accountAndList= driver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
		Actions action = new Actions(driver);
		action.moveToElement(accountAndList).click().build().perform();
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("pekiakaderick@gmail.com");
		action.moveToElement(driver.findElement(By.id("continue"))).click().build().perform();
        driver.findElement(By.cssSelector("#ap_password")).sendKeys("Patderick$123");
		driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
		String expectedResult="Hi, Derick";
		String actualExpect=driver.findElement(By.xpath("//h2[contains(text(),'Hi, Derick')]")).getText();
		System.out.println(actualExpect);
		Assert.assertEquals(actualExpect, expectedResult);
		
	}
	@Test
	public void selectingYourAddressTest() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='nav-global-location-popover-link']")).click();
		driver.findElement(By.id("GLUXZipUpdateInput")).sendKeys("75150");
		driver.findElement(By.xpath("//button[@name='glowDoneButton']")).click();
		Thread.sleep(5000);
		String expectedResult= "Hello";
		String actualResult=driver.findElement(By.xpath("//span[@id='glow-ingress-line1']")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectedResult);
	}
	@Test
	public void newItemRelease() {
		driver.findElement(By.xpath("//header/div[@id='navbar']/div[@id='nav-main']/div[2]/div[2]/div[1]/a[4]")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Appliances')]")).click();
		String expectedResult="New Releases in Appliances";
		String actualResult=driver.findElement(By.xpath("//h1[@class='a-size-large a-spacing-medium zg-margin-left-15 a-text-bold']")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectedResult);
	}
	@Test
	public void customerServices() {
		driver.findElement(By.xpath("//header/div[@id='navbar']/div[@id='nav-main']/div[2]/div[2]/div[1]/a[2]")).click();
		driver.findElement(By.linkText("Your Account")).click();
		driver.findElement(By.xpath("//h2[contains(text(),'Your Orders')]")).click();
		driver.findElement(By.id("ap_email")).sendKeys("pekiakaderick@gmail.com");
		driver.findElement(By.id("continue")).click();
		driver.findElement(By.id("ap_password")).sendKeys("Patderick$123");
		driver.findElement(By.id("signInSubmit")).click();
		String ExpertedResult = "Your Orders";
		String actualResult=driver.findElement(By.xpath("//h1[contains(text(),'Your Orders')]")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, ExpertedResult);
	}
	@Test
	public void kindleBookTest() throws InterruptedException {
		driver.findElement(By.xpath("//a[contains(text(),'Kindle Books')]")).click();
		driver.findElement(By.xpath("//body/div[@id='a-page']/div[2]/div[2]/div[2]/div[1]/div[1]/ul[1]/li[4]/a[1]")).click();
		Thread.sleep(5000);
		String expectResult="Sign in";
		String actualResult=driver.findElement(By.linkText("Sign in")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectResult);
	}
	
	@Test
	public void testingSearchBox() {
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("mens shoes");
		driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		String expectedResult="Eligible for Free Shipping";
		String actualResult=driver.findElement(By.xpath("//span[contains(text(),'Eligible for Free Shipping')]")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectedResult);
		
	}
	

}
