package testNg;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class testNgDemo1 {
	WebDriver driver;
	@BeforeTest
	public void webPageInitialization() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\cashp\\OneDrive\\Desktop\\ChromeDriver\\chromedriver.exe");
		 driver = new ChromeDriver();
			driver.get("http://demo.guru99.com/test/newtours/index.php");
			System.out.println(driver.getTitle());
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	}
	@AfterTest
	public void closePage() {
		driver.close();
	}
	@BeforeMethod
	public void comfirmeHomePage() {
		String actualTitle = driver.getTitle();
		String expectedTitle="Welcome: Mercury Tours";
		Assert.assertEquals(actualTitle, expectedTitle);
	}
	@AfterMethod
	public void backToHomePage() {
		driver.findElement(By.linkText("Home")).click();
	}
	@Test(dataProvider="loginfunctionality")
	public void loginFunctionality(String Username,String Password) {
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("Username");
		driver.findElement(By.name("password")).sendKeys("Password");
		driver.findElement(By.name("submit")).click();
		String expectedResult ="Login Successfully";
		String actualResult =driver.findElement(By.xpath("//tbody//tr//td//h3")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectedResult);
	}
	@DataProvider(name="loginfunctionality")
	public Object[][]  getData() {
		Object[][]data= {{"test123", "123"}};
		return data;		
	}
	@Test
	public void bookingFlight() {
		driver.findElement(By.linkText("Flights")).click();
		driver.findElement(By.xpath("//input[@value='roundtrip']")).click();
		WebElement NumberPassengers =driver.findElement(By.name("passCount"));
		    NumberPassengers.click();
		    Select number = new Select(NumberPassengers);
		    number.selectByValue("3");
		WebElement DepartureCity=driver.findElement(By.name("fromPort"));
		    DepartureCity.click();
		    Select city = new Select(DepartureCity);
		   city.selectByIndex(7); 
		WebElement DepartureMonth = driver.findElement(By.xpath("//tbody/tr[5]/td[2]/select[1]"));
		     DepartureMonth.click();
		     Select arrivingmonth = new Select(DepartureMonth);
		     arrivingmonth.selectByVisibleText("May");
		WebElement ArriverCity =driver.findElement(By.name("toPort"));
		     ArriverCity.click();
		     Select arrivecity= new Select(ArriverCity);
		     arrivecity.selectByIndex(5);
		WebElement Returningmonth =driver.findElement(By.name("toMonth"));
		     Returningmonth.click();
		     Select Returning = new Select(Returningmonth);
		     Returning.selectByIndex(7);
		driver.findElement(By.xpath("//input[@value='First']")).click();
		WebElement Airline = driver.findElement(By.xpath("//select[@name='airline']"));
		Airline.click();
		Select choiceAirline = new Select(Airline);
		choiceAirline.selectByIndex(2);
		driver.findElement(By.xpath("//input[@name='findFlights']")).click();
		String expectResult="After flight finder - No Seats Avaialble  ";
		String actualResult=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/p[1]/font[1]/b[1]/font[1]")).getText();
		System.out.println(actualResult);
		Assert.assertEquals(actualResult, expectResult);
		
	}
	@Test
	public void bookingForVacation() throws IOException {
		driver.findElement(By.linkText("Vacations")).click();
		WebElement underConstruction=driver.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
		File screenShot=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenShot,new File("C:\\Users\\cashp\\eclipse-workspace\\Selenium\\src\\testNg\\testNgDemo1\\underConstruction.png"));
		Assert.assertTrue(underConstruction.isDisplayed());
	}
	@Test
	public void bookingForHotels() {
	driver.findElement(By.linkText("Hotels")).click();
	WebElement underConstruction=driver.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
	Assert.assertTrue(underConstruction.isDisplayed());
	}
	@Test(dataProvider="registionInformation")
	public void newMembersRegistration(String firstname,String lastname,String phoneNumber,String Email,String Address,String city,String State,String PostalCode,String country,String UserName,String Password) throws InterruptedException {
		driver.findElement(By.linkText("REGISTER")).click();
		driver.findElement(By.name("firstName")).sendKeys(firstname);
		driver.findElement(By.name("lastName")).sendKeys(lastname);
		driver.findElement(By.name("phone")).sendKeys(phoneNumber);
		driver.findElement(By.id("userName")).sendKeys(Email);
		driver.findElement(By.name("address1")).sendKeys(Address);
		driver.findElement(By.xpath("//input[@name='city']")).sendKeys(city);
		driver.findElement(By.name("state")).sendKeys(State);
		driver.findElement(By.name("postalCode")).sendKeys(PostalCode);
		WebElement countryselect = driver.findElement(By.xpath("//tbody/tr[11]/td[2]/select[1]"));
		Select count = new Select(countryselect);
		count.selectByValue(country);
		driver.findElement(By.name("email")).sendKeys(UserName);
		driver.findElement(By.name("password")).sendKeys(Password);
		driver.findElement(By.name("confirmPassword")).sendKeys(Password);
		driver.findElement(By.name("submit")).click();
		//Thread.sleep(5000);
		WebElement registrationSuccessfulMsg = driver.findElement(By.xpath
				("//table[@width='492']/tbody/tr[3]/td/p[3]"));
		Assert.assertTrue(registrationSuccessfulMsg.isDisplayed());
	}
	@DataProvider(name="registionInformation")
	public Object[][]  getData1() {
		Object[][]information={{"Derick", "Maduku","+12144290619","pekiakaderick@gmail.com","1615 johnwest","Dallas","Texas","75228","ANGOLA","test123","123"}};
		return information;
	}
	@Test(enabled=false)
	public void paymentGateWay() {
		driver.findElement(By.xpath("//a[contains(text(),'Payment Gateway Project')]")).click();
		driver.findElement(By.xpath("//input[@class='button special']")).click();
		driver.findElement(By.xpath("//input[@id='card_nmuber']")).sendKeys("0123456789012345");
		WebElement month =driver.findElement(By.id("month"));
		month.click();
		Select select = new Select(month);
		select.selectByIndex(5);
		WebElement expire = driver.findElement(By.xpath("//select[@id='year']"));
		expire.click();
		Select year = new Select(expire);
		year.selectByIndex(9);
		driver.findElement(By.id("cvv_code")).sendKeys("456");
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		String expectedResult ="Payment successfull!";
		String actualResult=driver.findElement(By.xpath("//h2[contains(text(),'Payment successfull!')]")).getText();
		System.out.println(actualResult.toLowerCase());
		Assert.assertEquals(actualResult, expectedResult);
		
	}
	@Test
	public void contactSupportTeam() {
		driver.findElement(By.linkText("SUPPORT")).click();
		WebElement backToHomePage=driver.findElement(By.xpath("//tbody/tr[4]/td[1]/a[1]/img[1]"));
		Assert.assertTrue(backToHomePage.isDisplayed());
		}
	@Test(enabled=false)
	public void telecomProjectTest() {
		driver.findElement(By.xpath("//a[contains(text(),'Telecom Project')]")).click();
		driver.findElement(By.linkText("Add Customer")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Pending')]")).click();
		driver.findElement(By.id("fname")).sendKeys("Eric");
		driver.findElement(By.id("lname")).sendKeys("pekia");
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("pekiakaderick@gmail.com");
		driver.findElement(By.xpath("//textarea[@id='message']")).sendKeys("1615 Jonnwest Rd,mesquite TX75228");
		driver.findElement(By.id("telephoneno")).sendKeys("+1214390639");
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		driver.switchTo().alert().accept();
		WebElement AccessDetail=driver.findElement(By.xpath("//header//h1"));
		Assert.assertTrue(AccessDetail.isDisplayed());
		
	}
	@Test(enabled=false)
	public void seleniumTest() {
		WebElement page=driver.findElement(By.linkText("Selenium"));
		Actions action =new Actions(driver);
		action.moveToElement(page).click().build().perform();
		action.moveToElement(driver.findElement(By.linkText("Login"))).click().build().perform();
		String ExpectedResult="ALREADY REGISTERED?";		
		String ActualyResult =driver.findElement(By.xpath("//h3[contains(text(),'Already registered?')]")).getText();
		System.out.println(ActualyResult);
		Assert.assertEquals(ActualyResult, ExpectedResult);
		
		
	}
}
